package com.example.attendance

import UserDataManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat // 追加

class MainActivity : AppCompatActivity() {

    // --- 追加: 結果受信機 ---
    private val attendanceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("Attendance", "MainActivity: 放送を受信しました！")
            val response = intent?.getStringExtra("result") ?: ""
            Log.d("Attendance", "MainActivity: 受信データ: $response")
            val textStatus = findViewById<TextView>(R.id.tvStatusValue)

            if (response.startsWith("SUCCESS")) {
                // strings.xml の status_success を使用
                textStatus.text = getString(R.string.status_success)
                textStatus.setTextColor(Color.GREEN)
            } else {
                // strings.xml の status_error_format を使用（引数あり）
                textStatus.text = getString(R.string.status_error_format, response)
                textStatus.setTextColor(Color.RED)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!UserDataManager.isRegistered(this)) {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
            finish()
            return
        }
        setContentView(R.layout.activity_main)

        // 1. 画面上のパーツを取得
        val textUserInfo = findViewById<TextView>(R.id.textUserInfo)

        // 2. 保存されている情報を表示
        val studentId = UserDataManager.getStudentId(this)
        val userName = UserDataManager.getUserName(this)

        // 3. 画面にセット
        val infoText = getString(R.string.user_info_format, studentId, userName)
        textUserInfo.text = infoText

        // --- ここから追記：サービスを起動する ---
        Log.d("Attendance", "MainActivity: サービス起動を試みます")
        val serviceIntent = Intent(this, AttendanceService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        // ------------------------------------

        // --- 追加: レシーバー登録 (Android 14のエラー対策済) ---
        val filter = IntentFilter("com.example.attendance.ATTENDANCE_RESULT")
        ContextCompat.registerReceiver(
            this,
            attendanceReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    // --- 追加: 終了処理 ---
    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(attendanceReceiver)
        } catch (e: Exception) {
            // 解除済みの場合の回避
        }
    }
}