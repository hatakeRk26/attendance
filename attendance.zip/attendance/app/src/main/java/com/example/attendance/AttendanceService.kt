package com.example.attendance

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.concurrent.thread

class AttendanceService : Service() {

    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private val serverIp = "192.168.77.5"
    private val serverPort = 7777
    private val channelId = "attendance_channel"
    private val notificationId = 1

    override fun onCreate() {
        super.onCreate()
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("Attendance", "Service: onStartCommand - サービス開始")
        startForeground(notificationId, createNotification("Wi-Fi接続を待機中..."))
        registerWifiObserver()
        return START_STICKY
    }

    private fun registerWifiObserver() {
        Log.d("Attendance", "Observer: Wi-Fi監視を登録します")
        networkCallback?.let { connectivityManager.unregisterNetworkCallback(it) }

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            // IPアドレスが割り当てられた（DHCP完了）タイミングで呼ばれる
            override fun onLinkPropertiesChanged(network: Network, linkProperties: android.net.LinkProperties) {
                super.onLinkPropertiesChanged(network, linkProperties)
                Log.d("Attendance", "NetworkCallback: Wi-Fiを検知(onAvailable)")

                // IPv4アドレスが存在するかチェック
                val hasIpv4 = linkProperties.linkAddresses.any { it.address is java.net.Inet4Address }
                if (hasIpv4) {
                    Log.d("Attendance", "NetworkCallback: IPv4取得完了。送信処理へ移行します。")
                    thread {
                        // 少しだけ安定を待ってから送信
                        Thread.sleep(1000)
                        sendAttendanceWithResponse(network)
                    }
                }
            }

            override fun onLost(network: Network) {
                updateNotification("Wi-Fi切断: 出席待機中")
            }
        }

        connectivityManager.registerNetworkCallback(request, networkCallback!!)
    }

    private fun sendAttendanceWithResponse(network: Network) {
        val studentId = UserDataManager.getStudentId(this)
        val userName = UserDataManager.getUserName(this)
        val messageStr = "$studentId,$userName"
        val message = "$studentId,$userName".toByteArray()

        Log.d("Attendance", "UDP: 送信準備開始 (ID: $studentId, Name: $userName)")
        Log.d("Attendance", "UDP: ターゲットサーバー: $serverIp:$serverPort")

        try {
            val address = InetAddress.getByName(serverIp)

            DatagramSocket().use { socket ->
                Log.d("Attendance", "UDP: ソケット作成成功。ネットワークをバインドします。")
                // 重要: 指定したWi-Fiネットワークにソケットを紐付ける
                network.bindSocket(socket)
                socket.soTimeout = 5000 // 5秒間レスポンスを待つ

                // 1. 送信
                val sendPacket = DatagramPacket(message, message.size, address, serverPort)
                socket.send(sendPacket)
                Log.d("Attendance", "UDP: 送信パケットをネットワークに流しました: $messageStr")
                updateNotification("出席情報送信済み。判定待ち...")

                // 2. サーバーからの返信を受信
                val buffer = ByteArray(1024)
                val receivePacket = DatagramPacket(buffer, buffer.size)
                Log.d("Attendance", "UDP: サーバーからのレスポンスを待機中(5秒)...")

                try {
                    socket.receive(receivePacket)
                    val response = String(receivePacket.data, 0, receivePacket.length)
                    Log.i("Attendance", "UDP: サーバー応答受信成功! 内容: $response")

                    Log.d("Attendance", "Service: 画面に結果を放送します")
                    val broadcastIntent = Intent("com.example.attendance.ATTENDANCE_RESULT")
                    broadcastIntent.putExtra("result", response)
                    broadcastIntent.setPackage(packageName) // 同じアプリ内のみに制限（安全のため）
                    sendBroadcast(broadcastIntent)

                    // サーバーからの SUCCESS/ERROR に応じて通知を変える
                    if (response.startsWith("SUCCESS")) {
                        updateNotification("出席が確認されました: $userName")
                    } else {
                        updateNotification("エラー: $response")
                    }
                } catch (e: java.net.SocketTimeoutException) {
                    updateNotification("サーバーからの応答がありませんでした")
                }
            }
        } catch (e: Exception) {
            Log.e("Attendance", "通信エラー", e)
            updateNotification("送信エラー: ${e.message}")
        }
    }

    private fun createNotification(contentText: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "出席確認通知",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "出席管理システムの動作状態を表示します"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("出席管理システム")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val notification = createNotification(text)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(notificationId, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        networkCallback?.let {
            connectivityManager.unregisterNetworkCallback(it)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}